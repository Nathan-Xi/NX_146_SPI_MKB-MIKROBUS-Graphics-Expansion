#include <lcd_nv3022.h>
#include "font.h"
/* 码放入 Init 函数中 */
void LCD_Init(void) {
    // 1. 硬件复位
    BSP_LCD_Reset(1);
    Delay_ms(10);
    BSP_LCD_Reset(0);
    Delay_ms(200);
    BSP_LCD_Reset(1);
    Delay_ms(120);

    // 2. 厂家初始化序列
    LCD_NV3022_CMD(0xff);
    LCD_NV3022_Parameter(0xa5);
    LCD_NV3022_CMD(0x3a);
    LCD_NV3022_Parameter(0x65);
    LCD_NV3022_CMD(0x51);
    LCD_NV3022_Parameter(0x14);
    LCD_NV3022_CMD(0x53);
    LCD_NV3022_Parameter(0x11);
    LCD_NV3022_CMD(0x62);//HFP
    LCD_NV3022_Parameter(0x10);
    LCD_NV3022_CMD(0x86);
    LCD_NV3022_Parameter(0x01);//frc_en 01
    LCD_NV3022_CMD(0x87);
    LCD_NV3022_Parameter(0x1e);//4.7 gvdd
    LCD_NV3022_CMD(0x88);
    LCD_NV3022_Parameter(0x2B);//vcomh0
    LCD_NV3022_CMD(0x89);
    LCD_NV3022_Parameter(0x3C);//vcoml
    LCD_NV3022_CMD(0x61); //HBP
    LCD_NV3022_Parameter(0x10);
    LCD_NV3022_CMD(0x93);
    LCD_NV3022_Parameter(0x12);
    LCD_NV3022_CMD(0x94);
    LCD_NV3022_Parameter(0x10);
    LCD_NV3022_CMD(0x95);
    LCD_NV3022_Parameter(0x10);
    LCD_NV3022_CMD(0x96);
    LCD_NV3022_Parameter(0x0e);
    LCD_NV3022_CMD(0xb2);
    LCD_NV3022_Parameter(0x0F);
    LCD_NV3022_CMD(0xb4);
    LCD_NV3022_Parameter(0x60);
    LCD_NV3022_CMD(0x91);
    LCD_NV3022_Parameter(0x10);
    LCD_NV3022_CMD(0xC1);
    LCD_NV3022_Parameter(0xF1);
    LCD_NV3022_CMD(0xC5);
    LCD_NV3022_Parameter(0xF8);
    LCD_NV3022_CMD(0xb5);
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_CMD(0xc3);
    LCD_NV3022_Parameter(0x11);//ss/gs
    LCD_NV3022_CMD(0x83);
    LCD_NV3022_Parameter(0x13);//
    LCD_NV3022_CMD(0x44);
    LCD_NV3022_Parameter(0x00);

    // gamma_set
    LCD_NV3022_CMD(0x2a);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x84);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x84);
    LCD_NV3022_CMD(0x2b);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x1f);
    LCD_NV3022_CMD(0x2c);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x1c);//VPMIDP 15
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x16);//VRP1 10
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x1F);//VRP0 21
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x02);//KP7 0
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x08);//KP6 1
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x09);//KP5 2
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x10);//KP4 6
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x1f);//KP3 25
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x19);//KP2 29
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x1c);//KP1 30
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x1e);//KP0 31
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x03);//VPMIDN 15
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); //VRN0 21
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X07);//VRN1 10
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X01);//KN0 31
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X03);//KN1 30
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X01);//KN2 29
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X00);//KN3 25
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X0F);//KN4 6
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X0D);//KN5 2
    LCD_NV3022_Parameter(0X00);
    LCD_NV3022_Parameter(0X11);//KN6 1
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0X1D);//KN7 0

    LCD_NV3022_CMD(0xff);
    LCD_NV3022_Parameter(0x00);
    LCD_NV3022_CMD(0x21); // 反显(可选，有些屏需要加有些不需要，取决于偏光片)
    LCD_NV3022_CMD(0x11); // Sleep Out
    Delay_ms(120);

    LCD_NV3022_CMD(0x3a); // Color mode
    LCD_NV3022_Parameter(0x55); // 16-bit RGB565

    LCD_NV3022_CMD(0x36); // MADCTL - 扫描方向
    LCD_NV3022_Parameter(0x00);

    LCD_NV3022_CMD(0x29); // Display ON
    Delay_ms(10);

    /* 厂家给的默认窗口设置，通常画图/刷屏前会动态修改，这里保留原样或清除 */
    LCD_NV3022_CMD(0x2A);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x1C);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x62);
    LCD_NV3022_CMD(0x2B);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x00);
    LCD_NV3022_Parameter(0x00); LCD_NV3022_Parameter(0x9F);
    LCD_NV3022_CMD(0x2C);
}

/* 设置写入窗口 (重要！画图/刷图都需要依赖这个) */
void LCD_SetWindow(uint16_t xStar, uint16_t yStar, uint16_t xEnd, uint16_t yEnd) {
    // 加上硬件偏移量
    xStar += LCD_X_OFFSET;
    xEnd  += LCD_X_OFFSET;
    yStar += LCD_Y_OFFSET;
    yEnd  += LCD_Y_OFFSET;

    LCD_NV3022_CMD(0x2A); // 设定列地址
    LCD_NV3022_Parameter(xStar >> 8);
    LCD_NV3022_Parameter(0x00FF & xStar);
    LCD_NV3022_Parameter(xEnd >> 8);
    LCD_NV3022_Parameter(0x00FF & xEnd);

    LCD_NV3022_CMD(0x2B); // 设定行地址
    LCD_NV3022_Parameter(yStar >> 8);
    LCD_NV3022_Parameter(0x00FF & yStar);
    LCD_NV3022_Parameter(yEnd >> 8);
    LCD_NV3022_Parameter(0x00FF & yEnd);

    LCD_NV3022_CMD(0x2C); // 开始写入GRAM
}

/* 填充指定区域 */
void LCD_Fill(uint16_t xsta, uint16_t ysta, uint16_t xend, uint16_t yend, uint16_t color) {
    uint16_t i, j;
    LCD_SetWindow(xsta, ysta, xend, yend); // 设置窗口
    for(i = ysta; i <= yend; i++) {
        for(j = xsta; j <= xend; j++) {
            BSP_LCD_WriteData16(color); // 连续写入颜色数据
        }
    }
}

// 显示一张 RGB565 格式的图片
// x, y: 起点坐标 | width, height: 图片宽高 | p: 图片数组指针
void LCD_ShowImage(uint16_t x, uint16_t y, uint16_t width, uint16_t height, const uint16_t *p) {
    // 1. 设置只包含图片大小的显存窗口
    LCD_SetWindow(x, y, x + width - 1, y + height - 1);

    // 2. 连续写入图片像素数据
    uint32_t size = width * height;
    for(uint32_t i = 0; i < size; i++) {
        BSP_LCD_WriteData16(p[i]);
    }
}

// 显示单个 8x16 字符
// x, y: 坐标 | ch: 字符 | fc: 字体颜色 | bc: 背景颜色
void LCD_ShowChar(uint16_t x, uint16_t y, char ch, uint16_t fc, uint16_t bc) {
    uint8_t temp;
    uint8_t c = ch - ' '; // 计算该字符在字库数组中的偏移量

    // 直接框选一个 8x16 的窗口，这是最快的方法
    LCD_SetWindow(x, y, x + 7, y + 15);

    // 遍历该字符的 16 行
    for (uint8_t i = 0; i < 16; i++) {
        temp = asc2_1608[c][i]; // 取出当前行的 8 个像素信息
        // 遍历当前行的 8 个像素点 (从高位到低位)
        for (uint8_t j = 0; j < 8; j++) {
            if (temp & 0x80) {
                BSP_LCD_WriteData16(fc); // 是 1，画字体颜色
            } else {
                BSP_LCD_WriteData16(bc); // 是 0，画背景颜色
            }
            temp <<= 1; // 移位，准备读下一个像素
        }
    }
}

// 显示字符串
void LCD_ShowString(uint16_t x, uint16_t y, const char *str, uint16_t fc, uint16_t bc) {
    while (*str != '\0') {
        LCD_ShowChar(x, y, *str, fc, bc);
        x += 8; // 一个字符宽 8 像素，画完往右移 8 个像素
        str++;
    }
}

/* 清屏函数 */
void LCD_Clear(uint16_t color) {
    LCD_Fill(0, 0, LCD_WIDTH - 1, LCD_HEIGHT - 1, color);
}
