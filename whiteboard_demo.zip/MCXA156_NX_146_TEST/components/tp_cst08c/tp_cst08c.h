#ifndef _TP_CST08C_H_
#define _TP_CST08C_H_

#include "fsl_common.h"

#define CST08C_I2C_ADDR  0x15  // 海栎创经典地址

void CST08C_Init(void);
bool CST08C_ReadTouch(uint16_t *x, uint16_t *y);

#endif
