#include "tp_cst08c.h"
#include "bsp_i2c.h"
#include "fsl_gpio.h"

/* 复用 bsp_spi.h 里的延时函数 */
#include "bsp_spi.h"

/* 根据你的引脚图：
   TP_RST 是 GPIO3, Pin 20
   TP_INT 是 GPIO3, Pin 19
*/
#define TP_RST_GPIO  GPIO3
#define TP_RST_PIN   20U

void CST08C_Init(void) {
    // 1. 硬件复位触摸芯片 (拉低再拉高)
    GPIO_PinWrite(TP_RST_GPIO, TP_RST_PIN, 1U);
    Delay_ms(50);
    GPIO_PinWrite(TP_RST_GPIO, TP_RST_PIN, 0U);
    Delay_ms(50);
    GPIO_PinWrite(TP_RST_GPIO, TP_RST_PIN, 1U);

    // 给芯片 50ms 的时间启动并完成自校准
    Delay_ms(50);
}

/* 读取坐标 (返回 true 表示读到了有效触摸) */
bool CST08C_ReadTouch(uint16_t *x, uint16_t *y) {
    uint8_t buf[6];

    // 从 0x01 寄存器连读 6 个字节！
    // buf[0]=手势, buf[1]=手指数量
    // buf[2]=X高位, buf[3]=X低位
    // buf[4]=Y高位, buf[5]=Y低位
    if (BSP_I2C_ReadRegs(CST08C_I2C_ADDR, 0x01, buf, 6)) {

        // 如果有手指按下
        if (buf[1] > 0 && buf[1] <= 2) {
            // 提取 X 坐标 (去掉最高4位的状态位)
            *x = ((buf[2] & 0x0F) << 8) | buf[3];
            // 提取 Y 坐标 (去掉最高4位的状态位)
            *y = ((buf[4] & 0x0F) << 8) | buf[5];
            return true;
        }
    }
    return false;
}
