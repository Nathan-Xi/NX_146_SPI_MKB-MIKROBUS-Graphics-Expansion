/*
 * Copyright 2016-2026 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    MCXA156_NX_146_TEST.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
/* TODO: insert other include files here. */
#include "lcd_nv3022.h"
#include "tp_cst08c.h"
/* TODO: insert other definitions and declarations here. */
#define TP_INT_GPIO GPIO3
#define TP_INT_PIN  19U

#define TP_RST_GPIO GPIO3
#define TP_RST_PIN  20U
/*
 * @brief   Application entry point.
 */
int main(void) {

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    PRINTF("NV3022 + CST08C\r\n");

       /* 1. 初始化屏幕并清屏 */
    LCD_Init();
    LCD_Clear(WHITE); // 黑板准备好
    CST08C_Init();
    PRINTF("Touch Panel Ready\r\n");

    uint16_t raw_x, raw_y;
        uint16_t map_x, map_y;

        while (1) {
            if (GPIO_PinRead(GPIO3, 19U) == 0U) {

                // 1. 读取原始的、未经转换的坐标
                if (CST08C_ReadTouch(&raw_x, &raw_y)) {

                    // ==========================================
                    // 🛠️ 坐标系校准核心区
                    // ==========================================

                    // 第一步：解决“横竖相反” -> 把 X 和 Y 强行互换
                    map_x = raw_y;
                    map_y = raw_x;

                    // 第二步：解决“方向颠倒”（这步根据你的实际测试来调整！）
                    // 互换之后，你可能会发现手指往左划，白点却往右跑，或者上下反了。
                    // 如果【左右反了】，就把下面这行代码取消注释：
                    map_x = LCD_WIDTH - 1 - map_x;

                    // 如果【上下反了】，就把下面这行代码取消注释：
                    // map_y = LCD_HEIGHT - 1 - map_y;

                    // ==========================================

                    // 安全画点：防止越界导致屏幕花屏
                    if (map_x < LCD_WIDTH && map_y < LCD_HEIGHT) {
                        LCD_Fill(map_x, map_y, map_x + 2, map_y + 2, RED);
                    }
                }
            }
        }
}
