#include "bsp_spi.h"

#include "fsl_gpio.h"
#include "fsl_lpspi.h"

/* 控制复位引脚 */
void BSP_LCD_Reset(uint8_t state) {
    GPIO_PinWrite(LCD_RST_GPIO, LCD_RST_PIN, state);
}

/* 写 8 位命令 (RS = 0) */
void BSP_LCD_WriteCmd(uint8_t cmd) {
    GPIO_PinWrite(LCD_RS_GPIO, LCD_RS_PIN, 0U); // 拉低 RS 为命令模式

    lpspi_transfer_t xfer = {0};
    xfer.txData = &cmd;
    xfer.rxData = NULL;
    xfer.dataSize = 1;
    xfer.configFlags = kLPSPI_MasterPcs0 | kLPSPI_MasterPcsContinuous;

    LPSPI_MasterTransferBlocking(LPSPI0, &xfer);
}

/* 写 8 位数据 (RS = 1) */
void BSP_LCD_WriteData(uint8_t data) {
    GPIO_PinWrite(LCD_RS_GPIO, LCD_RS_PIN, 1U); // 拉高 RS 为数据模式

    lpspi_transfer_t xfer = {0};
    xfer.txData = &data;
    xfer.rxData = NULL;
    xfer.dataSize = 1;
    xfer.configFlags = kLPSPI_MasterPcs0 | kLPSPI_MasterPcsContinuous;

    LPSPI_MasterTransferBlocking(LPSPI0, &xfer);
}

/* 写 16 位像素数据 (用于刷屏, 优化速度) */
void BSP_LCD_WriteData16(uint16_t data) {
    uint8_t buf[2];
    buf[0] = data >> 8;   // 高字节在前 (大端传输)
    buf[1] = data & 0xFF; // 低字节在后

    GPIO_PinWrite(LCD_RS_GPIO, LCD_RS_PIN, 1U);

    lpspi_transfer_t xfer = {0};
    xfer.txData = buf;
    xfer.rxData = NULL;
    xfer.dataSize = 2;
    xfer.configFlags = kLPSPI_MasterPcs0 | kLPSPI_MasterPcsContinuous;

    LPSPI_MasterTransferBlocking(LPSPI0, &xfer);
}
