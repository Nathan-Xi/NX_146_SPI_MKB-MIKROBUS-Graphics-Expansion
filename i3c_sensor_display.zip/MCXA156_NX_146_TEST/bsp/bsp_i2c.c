#include "bsp_i2c.h"

/* NXP LPI2C 阻塞读取多个寄存器 */
bool BSP_I2C_ReadRegs(uint8_t deviceAddress, uint8_t regAddress, uint8_t *data, uint32_t length) {
    lpi2c_master_transfer_t masterXfer = {0};

    masterXfer.slaveAddress = deviceAddress;
    masterXfer.direction = kLPI2C_Read;
    masterXfer.subaddress = regAddress;     // 要读取的内部寄存器起始地址
    masterXfer.subaddressSize = 1;          // 寄存器地址长度通常为 1 字节
    masterXfer.data = data;                 // 数据存放的缓冲
    masterXfer.dataSize = length;           // 要读取的字节数
    masterXfer.flags = kLPI2C_TransferDefaultFlag;

    status_t status = LPI2C_MasterTransferBlocking(TOUCH_I2C_BASE, &masterXfer);

    return (status == kStatus_Success);
}
