#ifndef _BSP_SPI_H_
#define _BSP_SPI_H_

#include "fsl_common.h"

/* 根据你的 Config Tools 配置 */
#define LCD_RST_GPIO GPIO3
#define LCD_RST_PIN  29U

#define LCD_RS_GPIO  GPIO3
#define LCD_RS_PIN   30U

/* 延时函数宏定义 (依赖 NXP SDK 原生延时) */
#define Delay_ms(ms) SDK_DelayAtLeastUs((ms) * 1000U, SystemCoreClock)

/* 基础接口声明 */
void BSP_LCD_Reset(uint8_t state);
void BSP_LCD_WriteCmd(uint8_t cmd);
void BSP_LCD_WriteData(uint8_t data);
void BSP_LCD_WriteData16(uint16_t data);
void BSP_LCD_WriteDataArray(uint8_t *data, uint32_t len);

#endif
