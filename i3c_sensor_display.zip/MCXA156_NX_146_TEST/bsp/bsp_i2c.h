#ifndef _BSP_I2C_H_
#define _BSP_I2C_H_

#include "fsl_common.h"
#include "fsl_lpi2c.h"

/* 你的触摸 I2C 是 LPI2C3 */
#define TOUCH_I2C_BASE LPI2C3

bool BSP_I2C_ReadRegs(uint8_t deviceAddress, uint8_t regAddress, uint8_t *data, uint32_t length);

#endif
