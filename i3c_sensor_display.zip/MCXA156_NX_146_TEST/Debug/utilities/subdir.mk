################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../utilities/fsl_assert.c 

C_DEPS += \
./utilities/fsl_assert.d 

OBJS += \
./utilities/fsl_assert.o 


# Each subdirectory must supply rules for building sources it contributes
utilities/%.o: ../utilities/%.c utilities/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DCPU_MCXA156VLL -DCPU_MCXA156VLL_cm33 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -DSERIAL_PORT_TYPE_UART=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DSDK_DEBUGCONSOLE=0 -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\drivers" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\component\p3t1755" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\CMSIS" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\CMSIS\m-profile" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\utilities" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\utilities\debug_console" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\device" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\device\periph1" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\component\serial_manager" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\component\lists" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\utilities\str" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\component\uart" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\utilities\debug_console\config" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\component\gpio" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\board" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\source" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\components" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\components\lcd_nv3022" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\components\tp_cst08c" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace2\MCXA156_NX_146_TEST\bsp" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-utilities

clean-utilities:
	-$(RM) ./utilities/fsl_assert.d ./utilities/fsl_assert.o

.PHONY: clean-utilities

