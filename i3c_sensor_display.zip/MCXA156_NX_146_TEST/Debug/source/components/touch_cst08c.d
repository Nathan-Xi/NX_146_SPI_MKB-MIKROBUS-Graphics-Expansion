source/components/touch_cst08c.o source/components/touch_cst08c.d: \
 ../source/components/touch_cst08c.c \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/components/touch_cst08c.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/hw_ports/gpio_port.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_gpio.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_common.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/fsl_device_registers.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/MCXA156.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_ADC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/MCXA156_COMMON.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/core_cm33.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/cmsis_version.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/cmsis_compiler.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/cmsis_gcc.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/system_MCXA156.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/MCXA156_features.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_AOI.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CAN.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CDOG.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CMC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CRC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CTIMER.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_DEBUGMAILBOX.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_DMA.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_EIM.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_EQDC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_ERM.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FLEXIO.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FMC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FMU.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FMUTEST.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FREQME.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_GLIKEY.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_GPIO.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_I3C.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_INPUTMUX.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPCMP.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPDAC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPI2C.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPSPI.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPTMR.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPUART.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_MRCC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_OPAMP.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_OSTIMER.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_PORT.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_PWM.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_SCG.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_SPC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_SYSCON.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_TRDC.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_USB.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_UTICK.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_VBAT.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_WAKETIMER.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_WUU.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_WWDT.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_common_arm.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_clock.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_reset.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_port.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\board/board.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\board/clock_config.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_common.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/hw_ports/i2c_port.h \
 C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/hw_ports/delay_port.h
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/components/touch_cst08c.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/hw_ports/gpio_port.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_gpio.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_common.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/fsl_device_registers.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/MCXA156.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_ADC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/MCXA156_COMMON.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/core_cm33.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/cmsis_version.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/cmsis_compiler.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS/cmsis_gcc.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/system_MCXA156.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device/MCXA156_features.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_AOI.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CAN.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CDOG.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CMC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CRC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_CTIMER.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_DEBUGMAILBOX.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_DMA.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_EIM.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_EQDC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_ERM.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FLEXIO.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FMC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FMU.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FMUTEST.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_FREQME.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_GLIKEY.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_GPIO.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_I3C.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_INPUTMUX.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPCMP.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPDAC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPI2C.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPSPI.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPTMR.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_LPUART.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_MRCC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_OPAMP.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_OSTIMER.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_PORT.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_PWM.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_SCG.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_SPC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_SYSCON.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_TRDC.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_USB.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_UTICK.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_VBAT.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_WAKETIMER.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_WUU.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1/PERI_WWDT.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_common_arm.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_clock.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_reset.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_port.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\board/board.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\board/clock_config.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers/fsl_common.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/hw_ports/i2c_port.h:
C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source/hw_ports/delay_port.h:
