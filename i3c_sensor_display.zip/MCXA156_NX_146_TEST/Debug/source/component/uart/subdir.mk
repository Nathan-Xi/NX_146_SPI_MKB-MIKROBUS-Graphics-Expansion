################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../source/component/uart/fsl_adapter_lpuart.c 

C_DEPS += \
./source/component/uart/fsl_adapter_lpuart.d 

OBJS += \
./source/component/uart/fsl_adapter_lpuart.o 


# Each subdirectory must supply rules for building sources it contributes
source/component/uart/%.o: ../source/component/uart/%.c source/component/uart/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DCPU_MCXA156VLL -DCPU_MCXA156VLL_cm33 -DSDK_DEBUGCONSOLE=1 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -DSERIAL_PORT_TYPE_UART=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\drivers" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\CMSIS\m-profile" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\utilities" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\utilities\debug_console" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\device\periph1" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\utilities\str" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\utilities\debug_console\config" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\board" -I"C:\Users\Natha\Documents\MCUXpressoIDE_24.12.148\workspace\MCXA156_NX_146_TEST\source" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source-2f-component-2f-uart

clean-source-2f-component-2f-uart:
	-$(RM) ./source/component/uart/fsl_adapter_lpuart.d ./source/component/uart/fsl_adapter_lpuart.o

.PHONY: clean-source-2f-component-2f-uart

