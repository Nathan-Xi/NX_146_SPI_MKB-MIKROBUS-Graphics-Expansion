################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_SRCS := 
C_SRCS := 
OBJ_SRCS := 
O_SRCS := 
S_SRCS := 
S_UPPER_SRCS := 
C_DEPS := 
EXECUTABLES := 
OBJS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
board \
bsp \
component/gpio \
component/lists \
component/p3t1755 \
component/serial_manager \
component/uart \
components/lcd_nv3022 \
components/tp_cst08c \
device \
drivers \
source \
startup \
utilities/debug_console \
utilities \
utilities/str \

