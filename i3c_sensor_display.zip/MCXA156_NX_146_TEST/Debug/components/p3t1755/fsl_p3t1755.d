components/p3t1755/fsl_p3t1755.o components/p3t1755/fsl_p3t1755.d: \
 ../components/p3t1755/fsl_p3t1755.c
