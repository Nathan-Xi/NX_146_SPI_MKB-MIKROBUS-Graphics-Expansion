#ifndef _LCD_NV3022_H_
#define _LCD_NV3022_H_

#include "bsp_spi.h"

/* 请根据实际屏幕分辨率修改这两个值 */
#define LCD_WIDTH   70   // 示例宽度
#define LCD_HEIGHT  160  // 示例高度

#define LCD_X_OFFSET  29  // 厂家代码暗示 X 方向偏了 28 个像素
#define LCD_Y_OFFSET  0   // Y 方向暂时设为 0

/* 常用颜色定义 (RGB565) */
#define WHITE       0xFFFF
#define BLACK       0x0000
#define BLUE        0x001F
#define BRED        0XF81F
#define GRED        0XFFE0
#define GBLUE       0X07FF
#define RED         0xF800
#define GREEN       0x07E0

/* 宏定义替换厂家代码中的函数 */
#define LCD_NV3022_CMD(cmd)         BSP_LCD_WriteCmd(cmd)
#define LCD_NV3022_Parameter(data)  BSP_LCD_WriteData(data)

/* 接口函数 */
void LCD_Init(void);
void LCD_SetWindow(uint16_t xStar, uint16_t yStar, uint16_t xEnd, uint16_t yEnd);
void LCD_Fill(uint16_t xsta, uint16_t ysta, uint16_t xend, uint16_t yend, uint16_t color);
void LCD_ShowImage(uint16_t x, uint16_t y, uint16_t width, uint16_t height, const uint16_t *p);
void LCD_ShowChar(uint16_t x, uint16_t y, char ch, uint16_t fc, uint16_t bc);
void LCD_ShowString(uint16_t x, uint16_t y, const char *str, uint16_t fc, uint16_t bc);
void LCD_DrawPoint(uint16_t x, uint16_t y, uint16_t color);
void LCD_ShowChar_Sideways(uint16_t x, uint16_t y, char ch, uint16_t fc, uint16_t bc);
void LCD_ShowString_Sideways(uint16_t x, uint16_t y, const char *str, uint16_t fc, uint16_t bc);
void LCD_Clear(uint16_t color);

#endif
